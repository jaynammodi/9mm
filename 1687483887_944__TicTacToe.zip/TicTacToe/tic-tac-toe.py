import os.path
from tkinter import *
import sys
from collections import namedtuple

#sys.path.append('../')
#sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from games import *

ttt = TicTacToe(4, 4, 4)
root = None
buttons = []
frames = []
x_pos = []
o_pos = []
count = 0
sym = ""
result = None
choices = None


def create_frames(root):
    """
    This function creates the necessary structure of the game.
    """
    for _ in range(boardSize):
        framei = Frame(root)
        create_buttons(framei)
        framei.pack(side = TOP)
        frames.append(framei)

    uiFrame = Frame(root)
    buttonExit = Button(uiFrame, height=1, width=4, text="Exit", command=lambda: exit_game(root))
    buttonExit.pack(side=LEFT)
    uiFrame.pack(side=BOTTOM)
    buttonReset = Button(uiFrame, height=1, width=4,
                         text="Reset", command=lambda: reset_game())
    buttonReset.pack(side=LEFT)

butCount = 0
def create_buttons(frame):
    """
    creates the buttons for one row of the board .
    """
    buttons_in_frame = []
    global butCount

    for _ in range(boardSize):
        button = Button(frame, height=2, width=2, text=" ", padx=2, pady=2)
        button.config(command=lambda btn=button: on_click(btn))
        button.pack(side=LEFT)
        buttons_in_frame.append(button)
        butCount += 1

    buttons.append(buttons_in_frame)


def on_click(button):
    """
    This function determines the action of any button.
    """
    global ttt, choices, count, sym, result, x_pos, o_pos
    print("onClick: button.text=", button['text'])
    if count % 2 == 0:
        sym = "X"
    else:
        sym = "O"
    count += 1

    button.config(text=sym, state='disabled', disabledforeground="red")  # For cross

    x, y = get_coordinates(button)
    x += 1
    y += 1
    x_pos.append((x, y))
    state = gen_state(to_move='O', x_positions=x_pos,
                      o_positions=o_pos)
    try:
        choice = choices.get()
        if "Random" in choice:
            a, b = random_player(ttt, state)
        elif "Pro" in choice:
            a, b = minmax_decision(state, ttt)
        else:
            a, b = alpha_beta_player(ttt, state)
    except (ValueError, IndexError, TypeError) as e:
        disable_game()
        result.set("It's a draw :|")
        return
    if 1 <= a <= boardSize and 1 <= b <= boardSize:
        o_pos.append((a, b))
        button_to_change = get_button(a - 1, b - 1)
        if count % 2 == 0:  # Used again, will become handy when user is given the choice of turn.
            sym = "X"
        else:
            sym = "O"
        count += 1

        if check_victory(button):
            result.set("You win :)")
            disable_game()
        else:
            button_to_change.config(text=sym, state='disabled',
                                    disabledforeground="black")
            if check_victory(button_to_change):
                result.set("You lose :(")
                disable_game()


# TODO: Replace "check_victory" by "k_in_row" function.
def check_victory(button):
    """
    This function checks various winning conditions of the game.
    """
    # check if previous move caused a win on vertical line
    x, y = get_coordinates(button)
    tt = button['text']
    verticalWin = True
    for i in range(boardSize):
        if buttons[0][y]['text'] != buttons[i][y]['text']:
            verticalWin = False
            break

    if verticalWin == True:
        for i in range(boardSize):
            buttons[i][y].config(text="|" + tt + "|")
        return True

    # check if previous move caused a win on horizontal line
    horizontalWin = True
    for i in range(boardSize):
        if buttons[x][0]['text'] != buttons[x][i]['text']:
            horizontalWin = False
            break

    if horizontalWin == True:
        for i in range(boardSize):
            buttons[x][i].config(text="--" + tt + "--")
        return True


    # check if previous move was on the main diagonal and caused a win
    if x == y:
        diagonalWin = True
        for i in range(boardSize):
            if buttons[0][0]['text'] != buttons[i][i]['text']:
                diagonalWin = False
                break

        if diagonalWin == True:
            for i in range(boardSize):
                buttons[i][i].config(text="\\" + tt + "\\")
            return True


    # check if previous move was on the secondary diagonal and caused a win
    maxIndx = boardSize - 1
    if x + y == maxIndx:
        diagonalWin = True
        for i in range(boardSize):
            if buttons[0][maxIndx]['text'] != buttons[i][maxIndx-i]['text']:
                diagonalWin = False
                break

        if diagonalWin == True:
            for i in range(boardSize):
                buttons[i][maxIndx-i].config(text="/" + tt + "/")
            return True


    return False


def get_coordinates(button):
    """
    This function returns the coordinates of the button clicked.
    """
    for x in range(len(buttons)):
        for y in range(len(buttons[x])):
            if buttons[x][y] == button:
                return x, y


def get_button(x, y):
    """
    This function returns the button memory location corresponding to a coordinate.
    """
    return buttons[x][y]


def reset_game():
    """
    This function will reset all the tiles to the initial null value.
    """
    global x_pos, o_pos, frames, count

    count = 0
    x_pos = []
    o_pos = []
    result.set("Your Turn!")
    for x in frames:
        for y in x.winfo_children():
            y.config(text=" ", state='normal')


def disable_game():
    """
    This function deactivates the game after a win, loss or draw.
    """
    global frames
    for x in frames:
        for y in x.winfo_children():
            y.config(state='disabled')


def exit_game(root):
    """
    This function will exit the game by killing the root.
    """
    root.destroy()


if __name__ == "__main__":
    #global result, choices
    global boardSize

    if len(sys.argv) > 1:
        boardSize = int(sys.argv[1])
    else:
        boardSize = 3

    root = Tk()
    root.title("TicTacToe")
    root.geometry("220x280")  # Improved the window geometry
    root.resizable(0, 0)  # To remove the maximize window option
    result = StringVar()
    result.set("Your Turn!")
    w = Label(root, textvariable=result)
    w.pack(side=BOTTOM)
    create_frames(root)
    choices = StringVar(root)
    choices.set("Vs Pro")
    menu = OptionMenu(root, choices, "Vs Random", "Vs Pro", "Vs Legend")
    menu.pack()
    root.mainloop()
