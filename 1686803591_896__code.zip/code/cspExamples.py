
from cspProblem import Variable, CSP, Constraint
from operator import lt,ne,eq,gt

from csp import *
#from notebook import *

# Hide warnings in the matplotlib sections
import warnings
warnings.filterwarnings("ignore")
import ipywidgets as widgets
import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
from PIL import Image
from matplotlib import lines

def ne_(val):
    """not equal value"""
    # nev = lambda x: x != val # alternative definition
    # nev = partial(neq,val) # another alternative definition
    def nev(x):
        return val != x
    nev.__name__ = f"{val} != " # name of the function
    return nev


def is_(val):
    """is a value"""
    # isv = lambda x: x == val # alternative definition
    # isv = partial(eq,val) # another alternative definition
    def isv(x):
        return val == x
    isv.__name__ = f"{val} == "
    return isv


def example1():
    X = Variable('X', {1,2,3})
    Y = Variable('Y', {1,2,3})
    Z = Variable('Z', {1,2,3})
    csp0 = CSP("csp0", {X,Y,Z}, [ Constraint([X,Y],lt), Constraint([Y,Z],lt)])

    A = Variable('A', {1,2,3,4}, position=(0.2,0.9))
    B = Variable('B', {1,2,3,4}, position=(0.8,0.9))
    C = Variable('C', {1,2,3,4}, position=(1,0.4))
    C0 = Constraint([A,B], lt, "A < B", position=(0.4,0.3))
    C1 = Constraint([B], ne_(2), "B != 2", position=(1,0.9))
    C2 = Constraint([B,C], lt, "B < C", position=(0.6,0.1))
    csp1 = CSP("csp1", {A, B, C}, [C0, C1, C2])
    csp1.show()
#csp1s = CSP("csp1s", {A, B, C}, [C0, C2]) # A<B, B<C


def example2():
    A = Variable('A', {1,2,3,4}, position=(0.2,0.9))
    B = Variable('B', {1,2,3,4}, position=(0.8,0.9))
    C = Variable('C', {1,2,3,4}, position=(1,0.4))
    D = Variable('D', {1, 2, 3, 4}, position=(0, 0.4))
    E = Variable('E', {1, 2, 3, 4}, position=(0.5, 0))

    csp2 = CSP("csp2", {A, B, C, D, E},
        [Constraint([B], ne_(3), "B != 3", position=(1, 0.9)),
        Constraint([C], ne_(2), "C != 2", position=(1, 0.2)),
        Constraint([A, B], ne, "A != B"),
        Constraint([B, C], ne, "A != C"),
        Constraint([C, D], lt, "C < D"),
        Constraint([A, D], eq, "A = D"),
        Constraint([E, A], lt, "E < A"),
        Constraint([E, B], lt, "E < B"),
        Constraint([E, C], lt, "E < C"),
        Constraint([E, D], lt, "E < D"),
        Constraint([B, D], ne, "B != D")])

    csp2.show()


def example3():
    A = Variable('A', {1,2,3,4}, position=(0.2,0.9))
    B = Variable('B', {1,2,3,4}, position=(0.8,0.9))
    C = Variable('C', {1,2,3,4}, position=(1,0.4))
    D = Variable('D', {1, 2, 3, 4}, position=(0, 0.4))
    E = Variable('E', {1, 2, 3, 4}, position=(0.5, 0))
    csp3 = CSP("csp3", {A, B, C, D, E},
               [Constraint([A, B], ne, "A != B"), Constraint([A, D], lt, "A < D"),
                Constraint([A, E], lambda a, e: (a - e) % 2 == 1, "A-E is odd"),
                Constraint([B, E], lt, "B < E"),
                Constraint([D, C], lt, "D < C"),
                Constraint([C, E], ne, "C != E"),
                Constraint([D, E], ne, "D != E")])

    csp3.show()

def plot_NQueens(solution):
    n = len(solution)
    board = np.array([2 * int((i + j) % 2) for j in range(n) for i in range(n)]).reshape((n, n))
    im = Image.open('queen_s.png')
    height = im.size[1]
    im = np.array(im).astype(np.float) / 255
    fig = plt.figure(figsize=(7, 7))
    ax = fig.add_subplot(111)
    ax.set_title('{} Queens'.format(n))
    plt.imshow(board, cmap='binary', interpolation='nearest')
    # NQueensCSP gives a solution as a dictionary
    if isinstance(solution, dict):
        for (k, v) in solution.items():
            newax = fig.add_axes([0.064 + (k * 0.112), 0.062 + ((7 - v) * 0.112), 0.1, 0.1], zorder=1)
            newax.imshow(im)
            newax.axis('off')
    # NQueensProblem gives a solution as a list
    elif isinstance(solution, list):
        for (k, v) in enumerate(solution):
            newax = fig.add_axes([0.064 + (k * 0.112), 0.062 + ((7 - v) * 0.112), 0.1, 0.1], zorder=1)
            newax.imshow(im)
            newax.axis('off')
    fig.tight_layout()
    plt.show()


def eightQueen():
    eight_queens = NQueensCSP(8)
    solution = min_conflicts(eight_queens)
    plot_NQueens(solution)

def usingAC3():
    neighbors = parse_neighbors('A: B; B: ')
    domains = {'A': [0, 1, 2, 3, 4], 'B': [0, 1, 2, 3, 4]}
    constraints = lambda X, x, Y, y: x % 2 == 0 and (x + y) == 4 and y % 2 != 0
    removals = []

    csp = CSP(variables=None, domains=domains, neighbors=neighbors, constraints=constraints)

    result, checks = AC3(csp, removals=removals)
    print("result for AC3 consistency implementation is ", result, " and number of checks ", checks)

if __name__ == "__main__":
    #example1()
    #run example:
    #example3()

    #eightQueen()

    usingAC3()


